import javax.swing.*;   //The ScoreFrame class extends JFrame to display a window titled "Score" that shows a
import java.awt.*;      //list of scores from a ScoreStore, updating dynamically when showScores() is called.

public class ScoreFrame extends JFrame {
    private final ScoreStore scoreStore;
    private final JList<String> scoreList;
    public ScoreFrame(ScoreStore scoreStore){
        this.scoreStore = scoreStore;
        setPreferredSize(new Dimension(300, 400));
        setTitle("Score");
        String[] scoresArray = scoreStore.getScores().stream().map(Score::toString).toArray(String[]::new);
        this.scoreList = new JList<>(scoresArray);
        JScrollPane scrollPane = new JScrollPane(scoreList);
        add(scrollPane, BorderLayout.CENTER);
        pack();
    }
    public void showScores(){
        setVisible(true);
        scoreList.setListData(scoreStore.getScores().stream().map(Score::toString).toArray(String[]::new));
    }
}
