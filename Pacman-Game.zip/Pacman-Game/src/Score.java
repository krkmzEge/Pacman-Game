import java.io.Serializable;  //The Score class implements Serializable to allow instances to be serialized,
                              //and it encapsulates a player's name and score as immutable fields,
                              //providing methods to retrieve these values and a toString method for a string representation.
public class Score implements Serializable {
     private final String playerName;
     private final int score;

    public Score(String playerName, int score) {
        this.playerName = playerName;
        this.score = score;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        return playerName + ": " + score;
    }
}
