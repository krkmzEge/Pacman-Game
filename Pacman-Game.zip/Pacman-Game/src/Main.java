public class Main {
    public static void main(String[] args) {
        MenuFrame menuFrame = new MenuFrame();
        menuFrame.setVisible(true);
    }
}