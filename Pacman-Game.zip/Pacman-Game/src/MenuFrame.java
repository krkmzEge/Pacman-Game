import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

record ButtonInfo(String Title, ActionListener Action){}

public class MenuFrame extends JFrame {
    private GameFrame gameFrame;
    private ScoreStore scoreStore;
    private ScoreFrame scoreFrame;

    public MenuFrame() {
        this.scoreStore = new ScoreStore();
        this.scoreFrame = new ScoreFrame(scoreStore);
        this.gameFrame = new GameFrame(scoreStore);

        setTitle("Menu");
        setPreferredSize(new Dimension(850, 600));    //Size of the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        List<ButtonInfo> buttonInfos = new ArrayList<>(Arrays.asList(   //Menu buttons
                new ButtonInfo("Play", (e) -> {
                    gameFrame.start();
                }),
                new ButtonInfo("Scores", (e) -> {
                    scoreFrame.showScores();
                }),
                new ButtonInfo("Exit", (e) -> {
                    System.exit(0);
                })
        ));

        ImageIcon icon = new ImageIcon("resources/menu.jpg");  //Background of the menu
        Image image = icon.getImage();
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Dimension size = this.getSize();
                g.drawImage(image, 0, 0, size.width, size.height, this);
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        for (ButtonInfo btn : buttonInfos) {
            JButton button = new JButton(btn.Title());
            button.addActionListener(btn.Action());
            button.setAlignmentX(Component.CENTER_ALIGNMENT);        //This part of the code is centralize the buttons on the menu
            panel.add(Box.createVerticalGlue());
            panel.add(button);
        }
        panel.add(Box.createVerticalGlue());

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuFrame menuFrame = new MenuFrame();
            menuFrame.setVisible(true);
        });
    }
}

